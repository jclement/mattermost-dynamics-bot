ServiceStack makes use of the following OSS projects:

* Funq from Clarius Consulting and is released under the Microsoft Public License (Ms-PL): http://funq.codeplex.com/license
* Mono Project - more specifically, parts of the Mono BCL implementations (http://mono-project.com) and is used under the MIT license: http://www.mono-project.com/Licensing
* ICSharpCode SharpZipLib from the SharpDevelop project (http://sharpdevelop.net) and is used under the GPL license: http://sharpdevelop.net/OpenSource/SharpZipLib/
* ASP.NET MVC3 Razor Helpers and Support files and is released under the Microsoft Public License (Ms-PL)
* RazorEngine and is released under the Microsoft Public License (Ms-PL): http://razorengine.codeplex.com/license
* Log4Net (http://logging.apache.org/log4net/index.html) under the apache license: http://logging.apache.org/log4net/license.html
