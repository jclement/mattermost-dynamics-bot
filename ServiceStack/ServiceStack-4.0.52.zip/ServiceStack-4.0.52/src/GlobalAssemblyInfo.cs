using System.Reflection;

[assembly: AssemblyVersion("3.9.60.0")]
