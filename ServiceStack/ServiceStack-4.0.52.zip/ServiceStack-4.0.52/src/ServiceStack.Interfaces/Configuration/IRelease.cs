﻿namespace ServiceStack.Configuration
{
    public interface IRelease
    {
        void Release(object instance);
    }
}