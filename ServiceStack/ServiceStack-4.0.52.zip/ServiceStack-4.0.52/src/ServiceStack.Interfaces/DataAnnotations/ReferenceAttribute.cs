using System;

namespace ServiceStack.DataAnnotations
{
    [AttributeUsage(AttributeTargets.Property)]
    public class ReferenceAttribute : AttributeBase
    {
    }
}