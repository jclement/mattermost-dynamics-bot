﻿namespace ServiceStack
{
    public interface ICompressor
    {
        string Compress(string source);
    }
}