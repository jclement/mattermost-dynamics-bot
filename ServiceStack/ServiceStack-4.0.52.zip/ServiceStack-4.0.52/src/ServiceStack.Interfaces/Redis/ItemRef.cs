namespace ServiceStack.Redis
{
    public class ItemRef
    {
        public string Id { get; set; }
        public string Item { get; set; }
    }
}