﻿namespace ServiceStack.Redis
{
    public enum RedisClientType
    {
        Normal,
        Slave,
        PubSub,
    }
}